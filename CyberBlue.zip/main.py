import discord
from discord.ext import commands
from webserver import keep_alive
from discord.ext.commands import has_permissions, MissingPermissions
import os
bot = commands.Bot(command_prefix=",")
bot.remove_command('help')
@bot.event
async def on_connect():
  print ("DX bot has started!")
  await bot.change_presence(activity=discord.Activity(type=discord.ActivityType.listening, name="CyberBlue"))
#Moderation Commands
@bot.command()
@has_permissions(kick_members=True)
async def kick(ctx, member: discord.Member, *, reason=None):
	await member.kick(reason=reason)
	await ctx.send(f'User {member} has been kicked.. until they rejoin.')

@kick.error
async def kick_error(ctx, error):
	if isinstance(error, commands.MissingPermissions):
		await ctx.send("You don't have permissions to run this command!")


@bot.command()
@has_permissions(ban_members=True)
async def ban(ctx, member: discord.Member, *, reason=None):
	await member.ban(reason=reason)
	await ctx.send(f'User {member} has been **obliterated** from this universe')

@ban.error
async def ban_error(ctx, error):
	if isinstance(error, commands.MissingPermissions):
		await ctx.send("You don't have permission to run this command!")


  
#Informational Commands
@bot.command()
async def ping(ctx):
    await ctx.channel.send(f"Ping {round(bot.latency*2000)} ms")
@bot.command()
async def debug(ctx):
  await ctx.send ("galactic this")
@bot.command()
async def test(ctx):
  await ctx.send ("***test***\n***dodger***")
@bot.command()
async def help(ctx):
  await ctx.send ("test")

@has_permissions(manage_messages=True)
@bot.command()
async def purge(ctx, amount: int):
	await ctx.channel.purge(limit=amount)
@purge.error
async def purge_error(ctx, error):
	if isinstance(error, commands.MissingPermissions):
		await ctx.send("You don't have permissions to run this command!")
  
  
keep_alive()
TOKEN = os.environ.get("DISCORD_BOT_SECRET")
bot.run(TOKEN)